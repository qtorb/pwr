from .domain import TaskInput, RoutingDecision
from .mode_registry import get_mode_config


class DecisionEngine:
    """
    Decide eco o racing según señales simples.
    No ejecuta nada. Solo decide.
    """

    def decide(self, task: TaskInput) -> RoutingDecision:
        if task.preferred_mode in {"eco", "racing"}:
            config = get_mode_config(task.preferred_mode)
            return RoutingDecision(
                mode=config.mode,
                provider=config.provider,
                model=config.model,
                reasoning_path=f"He respetado el modo solicitado explícitamente: {task.preferred_mode}.",
                complexity_score=0.5 if task.preferred_mode == "eco" else 0.9,
            )

        combined = f"{task.title} {task.description} {task.context}".lower()
        score = 0.0
        reasons: list[str] = []

        if task.task_type == "Programar":
            score += 0.45
            reasons.append("la tarea es de programación")

        if task.task_type in {"Escribir", "Revisar"}:
            score += 0.20
            reasons.append("la tarea requiere estructura o revisión cuidada")

        if task.task_type == "Decidir":
            score += 0.25
            reasons.append("la tarea exige comparar alternativas")

        if len(combined) > 500:
            score += 0.20
            reasons.append("el input tiene bastante densidad contextual")

        strategic_terms = [
            "arquitectura", "estrategia", "trade-off", "prioridad",
            "roadmap", "diseño", "criterio", "decisión", "decision"
        ]
        if any(term in combined for term in strategic_terms):
            score += 0.25
            reasons.append("hay señales de razonamiento denso o estratégico")

        code_terms = ["python", "api", "bug", "sql", "deploy", "backend", "frontend"]
        if any(term in combined for term in code_terms):
            score += 0.20
            reasons.append("aparecen señales técnicas o de código")

        mode = "racing" if score >= 0.45 else "eco"
        config = get_mode_config(mode)

        if not reasons:
            reasons.append("la tarea parece acotada y de baja complejidad")

        reasoning_path = f"He elegido modo {mode} porque " + ", ".join(reasons) + "."

        return RoutingDecision(
            mode=config.mode,
            provider=config.provider,
            model=config.model,
            reasoning_path=reasoning_path,
            complexity_score=min(score, 1.0),
        )
